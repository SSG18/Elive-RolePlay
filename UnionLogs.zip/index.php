﻿<!DOCTYPE html>
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<title>UnlimitedLog</title>
<link href="./assets/styles.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="./js/jquery.js"></script>
<script type="text/javascript" src="./js/jquery.form.js"></script>
</head>
<body>
<div class="menu"><table width="100%">
<tbody><tr><td><ul><a href="/"><li>Главная</li>
<a href="https://rp-virginia.ru"><li>Сайт</li></a>
<a href="https://forum.rp-virginia.ru"><li>Форум</li></a></a></ul>
<a><ul></ul></a></td><td valign="top" align="right"></td>
<td valign="top" align="right">
<!-- <a href="/register.php" rel="no"><li>Регистрация</li></a> -->
<a href="/login.php"><li>Войти</li></a></td></tr></tbody></table></div>
<div class="menu"><table width="100%"><tbody><tr><td valign="top" align="left"><script>
	</script></td></tr></tbody></table></div>
    <div class="right"><div id="content">
    <table width="100%" border="0">
  <tbody>
    <tr>
      <td class="top"><h1>Серверы</h1></td>
    </tr>
    <tr>
      <td class="middel"><div class="box">
        <div class="boxtitle">Добрый день</div><p>Вы попали на сайт логов от Rp-Virginia.Ru.</div></td>
    </tr>
    <html>
<?
include("header/footer.php");
?>
</html>
</table>
</div></div>
</body></html>