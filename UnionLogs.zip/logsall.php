<?php 
session_start();
if(!isset($_SESSION["session_username"])) {
	header("location:login.php");
} else {
?>
<?
include("header/header.php");
?>
<h1 style="text-align: center;"><font color="1168a6"><font size="6"><font face="Tahoma, Geneva, sans-serif"> </font></font></font></h1><html>
	<head>
		<title>UnlimitedLog</title>
	<link href="assets/styles.css" rel="stylesheet" type="text/css">

	
</html>
<tr>
<td class="middel"><div class="box">
<div class="boxtitle">Логи сервера</div></td><p>

<?php

$result=mysqli_query($con,'SELECT * FROM logs_all ORDER BY date DESC LIMIT 0,200');
// берем результаты из каждой строки
while($row=mysqli_fetch_array($result))
	
 echo '<p>'.$row['date'].' - '.$row['action'].'</p></pre>';
 ?>
</div>


<html>
<?
include("header/footer.php");
?>
</html>
<?php
}
?>