<!DOCTYPE html>
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<title>UnlimitedLog</title>
<link href="./assets/styles.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="./js/jquery.js"></script>
<script type="text/javascript" src="./js/jquery.form.js"></script>
</head>
<body>
<div class="menu"><table width="100%">
<tbody><tr><td><ul><a href="/"><li>�������</li></a></ul>
<a><ul></ul></a></td><td valign="top" align="right"></td>
<td valign="top" align="right"><a href="/register.php" rel="no"><li>�����������</li></a>
<a href="/login.php"><li>�����</li></a></td></tr></tbody></table></div>
<div class="menu"><table width="100%"><tbody><tr><td valign="top" align="left"><script>
	</script></td></tr></tbody></table></div>
    <div class="right"><div id="content">
    <table width="100%" border="0">
  <tbody>
    <tr>
      <td class="top"><h1>�������</h1></td>
    </tr>
    <tr>
      <td class="middel"><div class="box">
        <div class="boxtitle">������ ����</div>�� ������ �� ���� ����� �� Rp-Virginia.Ru.</div></td>
    </tr>
    <tr>
      <td><center>
@2019 RP-Virginia.Ru
by HackChik</center></td>
    </tr>
  </tbody>
</table>
</div></div>
</body></html>