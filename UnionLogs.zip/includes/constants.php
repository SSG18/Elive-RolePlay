<?php

// Database Constants
define("DB_SERVER", "localhost");
define("DB_USER", "admin");
define("DB_PASS", "parol");
define("DB_NAME", "virginia");

?>